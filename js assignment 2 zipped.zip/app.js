const express=require('express');
// const pug=require("pug")
const PORT=9999;
const app=express();
const fs = require("fs");

app.set('view engine','pug');
app.set('views','./views');

app.use(express.json());
app.use(express.urlencoded({extended:false}));
app.use("/static",express.static("public"));
 //define routes 
 app.get("/",(req,res)=>{
    res.render("first_view");
 })
//  app.get("/login",(req,res)=>{
//     res.render("login");
//  })
app.get("/about",(req,res)=>{
    res.render("about");
})
app.get("/contact",(req,res)=>{
    res.render("contact");
}) 
app.post("/postdata",(req,res)=>{
    let name=req.body.name;
    let email=req.body.email;
    let message=req.body.message;

    // let userDetaills=name+","+email+","+message+"\n";
    // if(fs.existsSync("./users/contactDetails.txt")){
    //             fs.appendFile("./users/contactDetails.txt",`${userDetaills}`,(err)=>{
    //                 if (err) throw err
    //                  else   res.redirect("/contact")
    //           });
    //    }

    // if(fs.existsSync(`./users/${email}.txt`)){
    //     res.end('already exist')
    // }
    // else{
    //     fs.writeFile(`./users/${email}.txt`,`${name}\n${email}\n${message}`,(err)=>{
    //         if(err){
    //             res.end('something went wrong')
    //         }
    //         else{
    //             res.end('registration done sucessfully')
    //         }
    //     })
    // }


    if(fs.existsSync(`${email}`)){
        res.end("Already Exists");
    }
    else{
        
        fs.mkdir(`users/${email}`,(err)=>{
            if(err) throw err
            else {
    
                fs.writeFile(`users/${email}/details.txt`,`${name}\n${email}\n${message}`,(err)=>{
                    if(err) throw err
                    else res.end('File Created');
                })
              
    
            }
        })
    }
})
app.get("/service",(req,res)=>{
    res.render("service");
}) 
app.get("/gallery",(req,res)=>{
    res.render("gallery");
})  
app.listen(PORT,(err)=>{
    if(err) throw err;
    else console.log(`Server work on ${PORT}`)
})